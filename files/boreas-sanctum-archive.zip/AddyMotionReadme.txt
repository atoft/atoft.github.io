This is a custom campaign containing 3 maps created by Alastair Toft.

Please note this campaign was created several years ago when I was still learning Source SDK. It will contain bugs and errors and I will not be supporting this campaign.

Place the .vpk in your addons folder.