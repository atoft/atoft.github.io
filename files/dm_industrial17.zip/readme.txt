***** DM_INDUSTRIAL17 for Half-life 2 Deathmatch *****

To install: Unzip the map file "dm_industrial17.bsp".

Paste it in the Half-life 2 Deathmatch maps folder:
(Steam install location)\SteamApps\(Your Username)\half-life 2 deathmatch\hl2mp\maps\

Start the game and choose Create Server.

Enjoy!

Created by MisterAddy
AddyMotion.com