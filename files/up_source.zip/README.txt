Included are the source map files and scene files for the mod Half-Life 2: Uncertainty Principle, created by Alastair Toft.

Feel free to use however you wish. Attribution not neccesary.

